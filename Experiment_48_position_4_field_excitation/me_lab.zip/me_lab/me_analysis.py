import sys
import os
import logging

# Assuming 'src' is the main package directory containing models, utils, etc.
# Ensure that 'src/__init__.py' exists so that 'from src...' imports work.
sys.path.insert(0, 'src')

from src.utils.interface import get_paths_and_parameters
from src.models.experiment import Experiment
from src.plotting.plot_deps_vs_sample import plot_peak_amplitudes_vs_sample

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')


def main():
    # Get paths and parameters from the command-line interface
    # Adjust 'shared' as needed if your directory structure differs
    shared = '/home/hernan/Downloads/'
#     shared = '../../Experiments/im_yig_paper_data'
    paths_and_params = get_paths_and_parameters(shared)

    shared_path = paths_and_params['shared_path']
    date = paths_and_params['date']
    experiment = paths_and_params['experiment']
    selected_samples = paths_and_params['selected_samples']
    fs = paths_and_params['fs']
    idx = paths_and_params['idx']
    figures_base_path = paths_and_params['figures_base_path']
    reg_par = paths_and_params['reg_par']
    tau_sampling = paths_and_params['tau_sampling']
    N_tau = paths_and_params['N_tau']
    tau_min = paths_and_params['tau_min']
    tau_max = paths_and_params['tau_max']

    # Build the experiment path
    experiment_path = os.path.join(shared_path, date, experiment)

    # Initialize the Experiment class
    experiment_obj = Experiment(experiment_dir=experiment_path, figures_base_path=figures_base_path)

    # Load data for the selected samples
    experiment_obj.load_data(idx=idx, fs=fs, parse=True, sample_list=selected_samples)

    # Subtract channels to create gradientometric data (example: channel 0 - channel 1)
    experiment_obj.subtract_channels_in_all_samples(channel_num_1=0, channel_num_2=1)

    ch_num = 2
    plot_choice = input("\nDo you want to plot the raw data? (y/n) [default: n]: ").strip().lower()
    if plot_choice == 'y':
        experiment_obj.plot_raw(show=True)#, channel=ch_num)


    print(experiment_obj.subtract_baseline_from_all_samples(method='mean_end', n_points=500))


    # print(experiment_obj.subtract_baseline_from_all_samples(method='zero_sample', n_points=500))
    

    
    # experiment_obj.subtract_baseline_from_all_samples(method='3points')




    experiment_obj.plot_baseline_vs_sample(log_axes=False, ch_num=ch_num)

    # # Choose a channel number for ME-analysis
    # # Perform multi-exponential analysis
    # experiment_obj.perform_multiexponential_analysis_all_samples(N_tau=N_tau,
    #                                                              alpha=reg_par,
    #                                                              tau_min=tau_min,
    #                                                              tau_max=tau_max,
    #                                                              tau_sampling=tau_sampling,
    #                                                              channel_num=ch_num, 
    #                                                              method='l2' #'fixed_taus_baseline'#'fixed_taus'
    #                                                              )


    
    # # Plot pseudo-spectrum
    # experiment_obj.plot_pseudo_spectrum(plot_individual=True, show=True, channel_num=ch_num)

    # # Analyze pronounced peaks
    # experiment_obj.analyze_pronounced_peaks_per_sample(N_peaks=3, statistic='median')

    ## Plot amplitude of peaks vs sample property


    # plot_peak_amplitudes_vs_sample(experiment_obj, peak_idx=0, sample_properties=None, log_axes=True, exclude_zero_sample=True, use_sparsified=False, connect_points=True, x_label='Mass, $\mu$g', fit=True)
    # plot_peak_amplitudes_vs_sample(experiment_obj, peak_idx=1, sample_properties=None, log_axes=True, exclude_zero_sample=True, use_sparsified=False, connect_points=True, x_label='Mass, $\mu$g', fit=True)
    # plot_peak_amplitudes_vs_sample(experiment_obj, peak_idx=2, sample_properties=None, log_axes=True, exclude_zero_sample=True, use_sparsified=False, connect_points=True, x_label='Mass, $\mu$g', fit=True)

    plot_choice = input("\nDo you want to plot the raw data? (y/n) [default: n]: ").strip().lower()
    if plot_choice == 'y':
        experiment_obj.plot_raw(show=True, channel=ch_num)


if __name__ == "__main__":
    main()
