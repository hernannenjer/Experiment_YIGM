import numpy as np
import matplotlib.pyplot as plt
from src.analysis.me_analysis import perform_l2_analysis, sparcify_spectrum, create_basis
from src.analysis.curve_preprocessing import subtract_baseline_mean_end, subtract_baseline_3points

import sys
import os
import logging

# Assuming 'src' is the main package directory containing models, utils, etc.
# Ensure that 'src/__init__.py' exists so that 'from src...' imports work.
sys.path.insert(0, 'src')

# datafile = '../../Experiments/IM-YIG_v3/19.12.24/paa_dry_10ms_difference_s1/0.5.txt'
datafile1 = '../../Experiments/IM-YIG_v3/26.12.24/paa_agar_fs_10000_2mg/40/0.txt'
datafile2 = '../../Experiments/IM-YIG_v3/26.12.24/paa_agar_fs_10000_2mg/120/0.txt'


data1 = np.loadtxt(datafile1).T
data2 = np.loadtxt(datafile2).T

time1 = np.squeeze(data1[0,:])
time2 = np.squeeze(data2[0,:])
dead_time = 200e-3
where1 = np.argwhere(time1 > dead_time)
where2 = np.argwhere(time2 > dead_time)

signal1 = data1[1,:]
signal2 = data2[1,:]

print('signal1.shape = '+str(signal1.shape))
print('signal2.shape = '+str(signal2.shape))

max1 = np.max(signal1)
max2 = np.max(signal2)

# signal1, baseline1 = subtract_baseline_3points(signal1[None,:])
# signal1 = signal1.T
# 
# signal2, baseline2 = subtract_baseline_3points(signal2[None,:])
# signal2 = signal2.T

signal1, baseline1 = subtract_baseline_mean_end(signal1[None,:], n_points=100)
signal1 = signal1.T

signal2, baseline2 = subtract_baseline_mean_end(signal2[None,:], n_points=100)
signal2 = signal2.T

amplitude1 = max1 - baseline1
amplitude2 = max2 - baseline2


signal1 = signal1[where1]
signal2 = signal2[where2]

print('Baseline (40 mT) = '+str(baseline1)+' ; max='+str(max1)+' ; amplitude = '+str(amplitude1))
print('Baseline (120 mT) = '+str(baseline2)+' ; max='+str(max2)+' ; amplitude = '+str(amplitude2))
print('40 mT: ampl/baseline = '+str(amplitude1/baseline1))
print('120 mT: ampl/baseline = '+str(amplitude2/baseline2))

signal1 = np.squeeze(signal1)
signal2 = np.squeeze(signal2)
time1 = np.squeeze(time1)
time2 = np.squeeze(time2)

plt.plot(time1, signal1, label='40 mT')
plt.plot(time2, signal2, label='120 mT')
plt.legend()
plt.show()



# 
# 
# 
# # me analysis
# 
# N_tau = 1000
# alpha = 1e-1
# tau_min = 1e-3
# tau_max = 1500
# tau_sampling = 'non_uniform'
# 
# 
# 
# 
# 
# tau, spectrum, data_fit, norms = perform_l2_analysis(time, signal.T, N_tau=N_tau, 
#                                                  alpha=alpha, tau_min=tau_min,
#                                                  tau_max=tau_max, 
#                                                  tau_sampling = tau_sampling)
# 
# sparsified_amplitudes = np.zeros_like(spectrum)
# for i in range(spectrum.shape[0]):
#     sparsified_amplitudes[i, :] = sparcify_spectrum(tau, spectrum[i, :], min_peak_height=1e-8,
#                                                                      norms=norms)
# 
# 
# Phi, norms = create_basis(time, tau)
# sparse_refit = np.dot(sparsified_amplitudes, Phi/norms[:,None])
# print('sparse_refit.shape = '+str(sparse_refit.shape))
# 
# 
# print('===============')
# print('Spectrum = '+str(spectrum))
# print('spectrum.shape = '+str(spectrum.shape))
# plt.plot(tau, spectrum.T)
# # plt.plot(tau, sparsified_amplitudes.T)
# plt.show()
# 
# 
# plt.plot(time, signal, label='original')
# plt.plot(time, data_fit.T, label='fitted')
# plt.plot(time, sparse_refit.T, label='sparse_fit')
# plt.legend()
# plt.show()
# 
