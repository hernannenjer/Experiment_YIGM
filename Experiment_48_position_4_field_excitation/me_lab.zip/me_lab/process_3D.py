import sys
import os
import logging

# Add the "src" root package to sys.path
sys.path.insert(0, 'src')

from src.utils.interface import get_paths_and_parameters
from src.models.experiment import Experiment
# Or, if plot_3d_peak_heights is a separate function, not a method of Experiment:
from src.plotting.plot_3d import plot_3d_peak_heights


logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')


def main():
    # Retrieve paths and parameters
    shared = '/home/hernan/Downloads/'
    paths_and_params = get_paths_and_parameters(shared)
    
    shared_path = paths_and_params['shared_path']
    date = paths_and_params['date']
    experiment_name = paths_and_params['experiment']
    selected_samples = paths_and_params['selected_samples']
    fs = paths_and_params['fs']
    idx = paths_and_params['idx']
    figures_base_path = paths_and_params['figures_base_path']
    
    # Path to the experiment directory
    experiment_path = os.path.join(shared_path, date, experiment_name)

    # Initialize the Experiment object
    experiment_obj = Experiment(
        experiment_dir=experiment_path,
        figures_base_path=figures_base_path
    )

    # Load data
    logging.info("Loading data...")
    experiment_obj.load_data(
        idx=idx,
        fs=fs,
        parse=True,
        sample_list=selected_samples
    )

    # Optionally, allow the user to plot raw data
    plot_choice = input("\nDo you want to plot the raw data? (y/n) [default: n]: ").strip().lower()
    if plot_choice == 'y':
        experiment_obj.plot_raw(show=True)

    # Subtract the baseline (similar to me_analysis.py)
    experiment_obj.subtract_baseline_from_all_samples(method='mean_end', n_points=500)

    # Example: create a gradientometric channel (if needed)
    # experiment_obj.subtract_channels_in_all_samples(channel_num_1=0, channel_num_2=1)
    # experiment_obj.subtract_baseline_from_all_samples(method='mean_end', n_points=500)

    # Perform Multi-Exponential Analysis (if needed; regularization and range parameters are taken from paths_and_params)
    reg_par     = paths_and_params.get('reg_par', 1e-3)
    tau_sampling= paths_and_params.get('tau_sampling', 'log')
    N_tau       = paths_and_params.get('N_tau', 20)
    tau_min     = paths_and_params.get('tau_min', 1e-3)
    tau_max     = paths_and_params.get('tau_max', 5.0)
    ch_num      = 0   # or any other channel

    experiment_obj.perform_multiexponential_analysis_all_samples(
        N_tau      = N_tau,
        alpha      = reg_par,
        tau_min    = tau_min,
        tau_max    = tau_max,
        tau_sampling = tau_sampling,
        channel_num  = ch_num,
        method     = 'l2'
    )

    # If needed - analyze peaks to ensure all samples have the mean_peaks fields, etc.
    experiment_obj.analyze_pronounced_peaks_per_sample(N_peaks=1, statistic='median')

    # Now 3D coordinates
    coords_filename = os.path.join(experiment_path, 'coordinates.txt')
    amplitudes_filename = os.path.join(experiment_path, 'amplitudes.txt')

    # Call the 3D plotting function
    # If plot_3d_peak_heights is a method of Experiment:
    # experiment_obj.plot_3d_peak_heights(...)
    # If it is a regular function, pass experiment_obj as the first argument:
    sample_indices, peak_heights = plot_3d_peak_heights(
        experiment      = experiment_obj,
        coords_filename = coords_filename,
        N_peaks         = 1,
        point_size      = 10,
        cmap            = 'viridis',
        show            = True,
        rec            = None,  # Array of coordinates for "rec," if available
        gt             = None,  # Array of coordinates for "gt," if available
        point_label_fs = 55, 
        filename = amplitudes_filename
    )

    if sample_indices is None or peak_heights is None:
        logging.warning("No 3D data to plot or error in coordinates.")
    else:
        logging.info(f"Plotted {len(sample_indices)} points in 3D.")


if __name__ == "__main__":
    main()
