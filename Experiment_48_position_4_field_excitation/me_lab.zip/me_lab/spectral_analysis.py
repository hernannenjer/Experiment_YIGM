#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os
import logging

# Add 'src' folder to Python path
sys.path.insert(0, 'src')

from src.utils.interface import get_paths_and_parameters
from src.models.experiment import Experiment
from src.plotting.plot_deps_vs_sample import plot_psd_peak_vs_sample
import numpy as np
import matplotlib.pyplot as plt

logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')


def main():
    """
    Example script that:
      1) Loads data (parse=False),
      2) Computes Welc0
      h spectra only for ch_num=2 (or the default 0) if you prefer,
      3) Plots the PSD for that one channel in each attempt.
    """
    # 1. Read paths/parameters1
    shared = '/home/hernan/Downloads/'
    paths_and_params = get_paths_and_parameters(shared)
    shared_path       = paths_and_params['shared_path']
    date              = paths_and_params['date']
    experiment        = paths_and_params['experiment']
    selected_samples  = paths_and_params['selected_samples']
    fs                = paths_and_params['fs']
    figures_base_path = paths_and_params['figures_base_path']
    idx               = paths_and_params['idx']

    experiment_path = os.path.join(shared_path, date, experiment)

    # 2. Initialize and load data
    experiment_obj = Experiment(experiment_dir=experiment_path, figures_base_path=figures_base_path)
    experiment_obj.load_data(idx=idx, fs=fs, parse=False, sample_list=selected_samples)

    # 3. Choose which channel you want to process. Default is 0.
    #    For example, let's do channel #2:
    channel_of_interest = 0

    welch_params = {'nperseg': 13107200, 'noverlap': 512}
    experiment_obj.compute_spectra(ch_num=channel_of_interest, use_parsed=False, fs=fs, welch_params=welch_params)

    # 4. Plot the computed PSD for that channel
    plt.figure(figsize=(10, 6))
    for sample_name, sample in experiment_obj.samples.items():
        for attempt in sample.attempts:
            for channel in attempt.channels:
                if channel.channel_num == channel_of_interest and channel.freqs_spectra is not None:
                    label_str = f"{sample_name}_A{attempt.attempt_num}_Ch{channel.channel_num}"
                    plt.plot(channel.freqs_spectra, channel.psd_spectra, label=label_str)

    plt.title(f"Welch PSD (Channel {channel_of_interest}, Unparsed Data)")
    plt.xlabel("Frequency (Hz)")
    plt.ylabel("Power Spectral Density")
    plt.xlim((78, 81))
    plt.grid(True, ls="--", alpha=0.7)
    plt.legend()
    plt.tight_layout()

    save_fig_path = os.path.join(figures_base_path, f"welch_psd_ch{channel_of_interest}.png")
    plt.savefig(save_fig_path)
    logging.info(f"Saved PSD plot to: {save_fig_path}")
    plt.show()


    plot_psd_peak_vs_sample(
    experiment_obj,
    freq_range=(78, 81),
    sample_properties=None,
    log_axes=False,
    exclude_zero_sample=False,
    show_error=True,
    connect_points=True,
    x_label='Mass (mg)',
    fit=True
)


if __name__ == "__main__":
    main()
